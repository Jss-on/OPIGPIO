from setuptools import setup, find_packages

setup(
    name="OPIGPIO",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        # Any dependencies the package has can go here
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python package to handle GPIO on Orange Pi",
)
